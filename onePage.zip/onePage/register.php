
<style type="text/css">
    
    input,select{

        border-radius: 4px;
        box-shadow: 3px 3px 4px #000;
       width: 150px;
        color: blue;
        font-size: 14px;
    }

    label{
        margin-left: 20px;
        font-family: all;
    }
</style>


        <label>password:<input type="password" name="password" placeholder="password"></label><br><br>
        <label>Surname:<input type="text" name="Surname" placeholder="Surname"></label><br><br>
            <label>firstname:<input type="text" name="firstname" placeholder="firstname"></label><br><br>
                <label>phone:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="phone" name="phone" placeholder="phone"></label><br><br>
                    <label>Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="Email" name="Email" placeholder="Email"></label><br><br>
                        <label>Sex:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="Sex">
                            <option value="">--select--</option>
                            <option value="male">male</option>
                            <option value="female">female</option>
                        </select></label><br><br>
                            <label>State:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><select name="Tribe">
                                <option value="" >--select--</option>
                                <option value="Reuben" >Abia</option>
                                <option value="Simeon" >Adamawa</option>
                                <option value="Levi" >akwa-Ibom</option>
                                <option value="Judah" >Anambra</option>
                                <option value="Zebulun" >Bauchi</option>
                                <option value="Issachar" >Bayelsa</option>
                                <option value="Dan" >Benue</option>
                                
                        </select> <br><br>
                        <label>LGA:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><select name="State">
                            <option selected="Abia" value="Abia"> Abia</option>
                            <option value="Adamawa">Adamawa</option>
                            <option value="Akwa-Ibom">Akwa-Ibom</option>
                        </select><br><br>

                        <button>Register</button>


