

/*=============================================================
    Authour:chima chima chinonso
   

   

    100% Free To use For Personal And Commercial Use.
    IN EXCHANGE JUST GIVE US CREDITS AND TELL YOUR FRIENDS ABOUT US
   
    ========================================================  */


$("a").click(function (e){

	var btnId ="section"+e.currentTarget.id;

	$('html,body') .animate({
		scrollTop: $("#" + btnId).offset().top
	},1000);
});


