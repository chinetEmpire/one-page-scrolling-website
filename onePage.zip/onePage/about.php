<div class="overlay"><br>
	

	<div id="abt">

	<div><img id="img" src="img/img1.jpg"></div>
	
</div>	

<div id="slid">
	<h2 style="text-align: center; color: maroon; font-family: cursive; text-decoration: underline;">NUCLUES VENTURES LIMITED</h2>
	<P style="text-align: center;">The company has continued to grow at highly encouraging rates from year to year. this is evidenced by its trading summary for the past 5 years. Nucleus embarked on diversification snce year 2000 with the following sister companies coming on stream.</P>

	<header style="text-align: center;">NUCLUES MOTORS AND HAULAGE LIMITED</header>
	<p>With over 15 trucks on fleet, Nucleus Motors & Haulage run haulage services both within the state and also provide interstate services. </p>

<header style="text-align: center;">NUCLUES PROPERTIES LIMITED</header>
	<p>NPL has evolved to be one of the country's foremost property developing companies involved in building and selling of properties,housing units & office blocks. We also work with property developers in Lagos State with expansion projects in view for other states. </p>

<header style="text-align: center;">LUCKY PAPER MILL LIMITED</header>

<P>

We specialize in the manufacture,sales and delivery of various paper products within and outside Lagos State. </P>

<header style="text-align: center;">NUCLUES POWER AND ENERGY</header>
<P>We supply petroleum products such as Petrol,{PMS}, Diesel {AGO},Black Oil {LPFO},Kerosene {DPK}, Cooking gas {LPG} to manufacturing, construction and other related companies.</P>

</div>	



</div>	
</div>