<div id="mission">

<div style="float: right; margin-left: 5px;">
	<div id="mi"><br>
		<header>OUR MISSION</header><br>
		<h3>To provide customers with high <br>
		     quality products to meet their unique<br> needs
		     using the best available technology and a highly<br> motivated workfprce.</h3>
	</div>



	<div id="vi"><br>
		<header>OUR VISSION</header><br>
		<h3>Our vission is to be a leader in <br>
		     manufacturing, distribution and merchandizing<br>of all  paper products 
		<br> in Nigeria.</h3>
	</div>
</div>
<div class="login">

<div class="log-box">
<img src="img/user.png" id="pix">
<div id="time"><?php
                        $Today = date('y:m:d');
                        $new = date('l, F d, Y', strtotime($Today));
                        echo $new;
                        ?>
</div>
<p style="color: #fff; text-align: center; font-size: 16px; font-weight: bold; background-color: ">Staff Login portal</p>

	<form >
	<div class="form-input">
	<input type="text" name="username" placeholder="Enter username">
	</div>
		
		<div class="form-input"> 
		<input type="password" name="password" placeholder="Enter password">
		
		</div>
		<button id="log">login</button>

		<br><a id="reg"  href="#reg" onclick="document.getElementById('id01').style.display='block'" ">Staff Register</a>
	</form>
	
</div>
	

</div>

</div>

 




</div>
